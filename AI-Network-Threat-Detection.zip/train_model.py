"""
train_model.py
==================================================
Production-grade ML training pipeline for network
intrusion / threat detection (CICIDS2017).

THE ARZENS Internship - Assignment 4, Task 2
==================================================

Usage:
    python train_model.py --config config.yaml

Pipeline stages:
    load_data()       -> Data ingestion & validation
    preprocess()      -> Feature engineering + imbalance handling
    train_models()    -> Train RF, XGBoost, (optional) Neural Net w/ tuning
    evaluate_cv()      -> Cross-validated performance summary
    save_artifacts()  -> Persist model, scaler, feature list, logs
    main()            -> Orchestration
"""

import os
import sys
import json
import time
import glob
import hashlib
import argparse
import warnings
from datetime import datetime

import yaml
import joblib
import numpy as np
import pandas as pd

from sklearn.model_selection import (
    train_test_split, StratifiedKFold, RandomizedSearchCV, GridSearchCV, cross_val_score
)
from sklearn.preprocessing import StandardScaler, MinMaxScaler, LabelEncoder
from sklearn.ensemble import RandomForestClassifier
from sklearn.metrics import f1_score, make_scorer

warnings.filterwarnings("ignore")

RANDOM_STATE_DEFAULT = 42


# ----------------------------------------------------------------------
# Utility
# ----------------------------------------------------------------------

def load_config(path: str) -> dict:
    with open(path, "r") as f:
        return yaml.safe_load(f)


def file_checksum(path: str, chunk_size: int = 8192) -> str:
    """Return an md5 checksum for dataset versioning / reproducibility."""
    h = hashlib.md5()
    with open(path, "rb") as f:
        for chunk in iter(lambda: f.read(chunk_size), b""):
            h.update(chunk)
    return h.hexdigest()


# ----------------------------------------------------------------------
# 1. Data Ingestion & Validation
# ----------------------------------------------------------------------

def load_data(cfg: dict) -> pd.DataFrame:
    """
    Downloads (or reuses cached) CICIDS2017 dataset via kagglehub, locates
    the CSV, validates schema/quality, and returns a raw DataFrame.
    """
    import kagglehub

    print("[load_data] Downloading / locating dataset via kagglehub ...")
    dataset_path = kagglehub.dataset_download(cfg["data"]["kaggle_dataset"])
    print(f"[load_data] Dataset path: {dataset_path}")

    csv_name = cfg["data"].get("csv_filename")
    if csv_name:
        csv_path = os.path.join(dataset_path, csv_name)
        if not os.path.exists(csv_path):
            raise FileNotFoundError(f"Configured csv_filename not found: {csv_path}")
    else:
        # Auto-detect: pick the largest CSV in the downloaded folder tree
        candidates = glob.glob(os.path.join(dataset_path, "**", "*.csv"), recursive=True)
        if not candidates:
            raise FileNotFoundError(f"No CSV files found under {dataset_path}")
        csv_path = max(candidates, key=os.path.getsize)
        print(f"[load_data] Auto-selected CSV: {csv_path} "
              f"({os.path.getsize(csv_path) / 1e6:.1f} MB)")

    checksum = file_checksum(csv_path)
    print(f"[load_data] Dataset checksum (md5): {checksum}")

    df = pd.read_csv(csv_path, low_memory=False)
    df.columns = [c.strip() for c in df.columns]  # CICIDS2017 has leading spaces

    print(f"[load_data] Loaded shape: {df.shape}")

    # ---- Schema / quality validation ----
    n_nulls = df.isnull().sum().sum()
    n_dupes = df.duplicated().sum()
    n_inf = np.isinf(df.select_dtypes(include=[np.number])).sum().sum()
    print(f"[load_data] Nulls: {n_nulls} | Duplicates: {n_dupes} | Inf values: {n_inf}")

    # Replace inf with NaN, then drop rows with any NaN (common CICIDS2017 issue
    # from division-by-zero flow rate features)
    df.replace([np.inf, -np.inf], np.nan, inplace=True)
    before = len(df)
    df.dropna(inplace=True)
    after = len(df)
    print(f"[load_data] Dropped {before - after} rows with NaN/Inf ({after} remaining)")

    df.drop_duplicates(inplace=True)

    # Drop identifier-like columns if present
    for col in cfg["data"]["drop_columns"]:
        if col in df.columns:
            df.drop(columns=[col], inplace=True)

    # Locate label column (case-insensitive, tolerant of naming variants)
    label_col_cfg = cfg["data"]["label_column"]
    label_col = None
    for c in df.columns:
        if c.strip().lower() == label_col_cfg.strip().lower():
            label_col = c
            break
    if label_col is None:
        # fallback: any column literally named "label" or "Label"
        for c in df.columns:
            if "label" in c.lower():
                label_col = c
                break
    if label_col is None:
        raise ValueError("Could not locate a label column in the dataset.")

    if label_col != "Label":
        df.rename(columns={label_col: "Label"}, inplace=True)

    print(f"[load_data] Class distribution:\n{df['Label'].value_counts()}")

    return df


# ----------------------------------------------------------------------
# 2. Feature Engineering
# ----------------------------------------------------------------------

def preprocess(df: pd.DataFrame, cfg: dict):
    """
    Encodes labels, scales numeric features, removes highly-correlated
    duplicates, splits into train/val/test, and applies class-imbalance
    handling (SMOTE or class weights) on the TRAIN split only.
    """
    task_type = cfg["data"]["task_type"]
    benign_label = cfg["data"]["benign_label"].lower()
    rs = cfg["project"]["random_state"]

    y_raw = df["Label"].astype(str)
    X = df.drop(columns=["Label"])

    # Keep only numeric features (CICIDS2017 is almost entirely numeric already)
    X = X.select_dtypes(include=[np.number]).copy()

    if task_type == "binary":
        y = (y_raw.str.lower() != benign_label).astype(int)  # 1 = attack, 0 = benign
        class_names = ["Benign", "Attack"]
    else:
        le = LabelEncoder()
        y = le.fit_transform(y_raw)
        class_names = list(le.classes_)

    # ---- Feature selection: drop near-duplicate correlated features ----
    corr_thresh = cfg["preprocessing"]["correlation_threshold"]
    corr_matrix = X.corr().abs()
    upper = corr_matrix.where(np.triu(np.ones(corr_matrix.shape), k=1).astype(bool))
    to_drop = [col for col in upper.columns if any(upper[col] > corr_thresh)]
    if to_drop:
        print(f"[preprocess] Dropping {len(to_drop)} highly-correlated features "
              f"(> {corr_thresh}): {to_drop[:10]}{'...' if len(to_drop) > 10 else ''}")
        X.drop(columns=to_drop, inplace=True)

    feature_list = list(X.columns)

    # ---- Split: train / val / test (stratified) ----
    test_size = cfg["data"]["test_size"]
    val_size = cfg["data"]["val_size"]

    X_train_full, X_test, y_train_full, y_test = train_test_split(
        X, y, test_size=test_size, stratify=y, random_state=rs
    )
    val_relative = val_size / (1 - test_size)
    X_train, X_val, y_train, y_val = train_test_split(
        X_train_full, y_train_full, test_size=val_relative,
        stratify=y_train_full, random_state=rs
    )

    print(f"[preprocess] Split sizes -> train: {len(X_train)}, "
          f"val: {len(X_val)}, test: {len(X_test)}")

    # ---- Scaling (fit on train only) ----
    scaler = StandardScaler() if cfg["preprocessing"]["scaler"] == "standard" else MinMaxScaler()
    X_train_scaled = scaler.fit_transform(X_train)
    X_val_scaled = scaler.transform(X_val)
    X_test_scaled = scaler.transform(X_test)

    # ---- Class imbalance handling (train split only) ----
    strategy = cfg["preprocessing"]["imbalance_strategy"]
    sample_weight = None
    if strategy == "smote":
        from imblearn.over_sampling import SMOTE
        print("[preprocess] Applying SMOTE oversampling to training data ...")
        smote = SMOTE(k_neighbors=cfg["preprocessing"]["smote_k_neighbors"], random_state=rs)
        X_train_scaled, y_train = smote.fit_resample(X_train_scaled, y_train)
        print(f"[preprocess] Post-SMOTE train class distribution: "
              f"{np.bincount(y_train)}")
    elif strategy == "class_weight":
        print("[preprocess] Using class_weight='balanced' during model training.")
    else:
        print("[preprocess] No imbalance handling applied.")

    bundle = {
        "X_train": X_train_scaled, "y_train": y_train,
        "X_val": X_val_scaled, "y_val": y_val,
        "X_test": X_test_scaled, "y_test": y_test,
        "scaler": scaler,
        "feature_list": feature_list,
        "class_names": class_names,
        "imbalance_strategy": strategy,
    }
    return bundle


# ----------------------------------------------------------------------
# 3 & 4. Model Training + Hyperparameter Tuning
# ----------------------------------------------------------------------

def _tuned_search(estimator, param_grid, cfg, X, y):
    rs = cfg["project"]["random_state"]
    cv = StratifiedKFold(n_splits=cfg["tuning"]["cv_folds"], shuffle=True, random_state=rs)
    scorer = make_scorer(f1_score)

    if cfg["tuning"]["method"] == "grid_search":
        search = GridSearchCV(estimator, param_grid, scoring=scorer, cv=cv, n_jobs=-1)
    else:
        search = RandomizedSearchCV(
            estimator, param_grid, scoring=scorer, cv=cv, n_jobs=-1,
            n_iter=cfg["tuning"]["n_iter"], random_state=rs
        )
    search.fit(X, y)
    return search.best_estimator_, search.best_params_, search.best_score_


def train_models(bundle: dict, cfg: dict) -> dict:
    """
    Trains Random Forest, XGBoost, and (optionally) a Neural Network,
    each with hyperparameter search over the training set.
    Returns a dict of {model_name: {"model":..., "best_params":..., "train_time":...}}
    """
    X_train, y_train = bundle["X_train"], bundle["y_train"]
    rs = cfg["project"]["random_state"]
    results = {}
    log_rows = []

    # ---- Random Forest ----
    if cfg["models"]["random_forest"]["enabled"]:
        print("\n[train_models] Training Random Forest ...")
        t0 = time.time()
        rf = RandomForestClassifier(
            random_state=rs, class_weight=cfg["models"]["random_forest"]["class_weight"], n_jobs=-1
        )
        best_rf, best_params, best_score = _tuned_search(
            rf, cfg["models"]["random_forest"]["param_grid"], cfg, X_train, y_train
        )
        elapsed = time.time() - t0
        print(f"[train_models] RF best CV f1={best_score:.4f} params={best_params} "
              f"({elapsed:.1f}s)")
        results["random_forest"] = {"model": best_rf, "best_params": best_params,
                                     "cv_f1": best_score, "train_time": elapsed}
        log_rows.append(["random_forest", best_score, elapsed, json.dumps(best_params)])

    # ---- XGBoost ----
    if cfg["models"]["xgboost"]["enabled"]:
        print("\n[train_models] Training XGBoost ...")
        try:
            from xgboost import XGBClassifier
        except ImportError:
            print("[train_models] xgboost not installed, skipping.")
            XGBClassifier = None

        if XGBClassifier is not None:
            t0 = time.time()
            scale_pos_weight = (y_train == 0).sum() / max((y_train == 1).sum(), 1) \
                if cfg["preprocessing"]["imbalance_strategy"] == "class_weight" else 1
            xgb = XGBClassifier(
                random_state=rs, eval_metric="logloss",
                scale_pos_weight=scale_pos_weight, n_jobs=-1
            )
            best_xgb, best_params, best_score = _tuned_search(
                xgb, cfg["models"]["xgboost"]["param_grid"], cfg, X_train, y_train
            )
            elapsed = time.time() - t0
            print(f"[train_models] XGBoost best CV f1={best_score:.4f} params={best_params} "
                  f"({elapsed:.1f}s)")
            results["xgboost"] = {"model": best_xgb, "best_params": best_params,
                                  "cv_f1": best_score, "train_time": elapsed}
            log_rows.append(["xgboost", best_score, elapsed, json.dumps(best_params)])

    # ---- Neural Network (optional bonus) ----
    if cfg["models"]["neural_network"]["enabled"]:
        print("\n[train_models] Training Neural Network ...")
        try:
            import tensorflow as tf
            from tensorflow.keras import layers, models, callbacks
        except ImportError:
            print("[train_models] tensorflow not installed, skipping NN.")
            tf = None

        if tf is not None:
            t0 = time.time()
            nn_cfg = cfg["models"]["neural_network"]
            tf.random.set_seed(rs)

            model = models.Sequential()
            model.add(layers.Input(shape=(X_train.shape[1],)))
            for units in nn_cfg["architecture"]:
                model.add(layers.Dense(units, activation="relu"))
                model.add(layers.Dropout(nn_cfg["dropout"]))
            model.add(layers.Dense(1, activation="sigmoid"))

            model.compile(
                optimizer=tf.keras.optimizers.Adam(learning_rate=nn_cfg["learning_rate"]),
                loss="binary_crossentropy",
                metrics=["accuracy", tf.keras.metrics.AUC(name="auc")]
            )

            es = callbacks.EarlyStopping(
                monitor="val_loss", patience=nn_cfg["early_stopping_patience"],
                restore_best_weights=True
            )

            history = model.fit(
                X_train, y_train,
                validation_data=(bundle["X_val"], bundle["y_val"]),
                epochs=nn_cfg["epochs"], batch_size=nn_cfg["batch_size"],
                callbacks=[es], verbose=2
            )
            elapsed = time.time() - t0
            final_val_auc = history.history["val_auc"][-1]
            print(f"[train_models] NN final val AUC={final_val_auc:.4f} ({elapsed:.1f}s)")
            results["neural_network"] = {
                "model": model, "best_params": nn_cfg, "cv_f1": None,
                "train_time": elapsed, "history": history.history
            }
            log_rows.append(["neural_network", final_val_auc, elapsed, json.dumps(nn_cfg)])

    # Persist a training log CSV
    log_df = pd.DataFrame(log_rows, columns=["model", "cv_score", "train_time_sec", "best_params"])
    results["_training_log"] = log_df

    return results


# ----------------------------------------------------------------------
# Cross-validation summary (in addition to the CV already used for tuning)
# ----------------------------------------------------------------------

def evaluate_cv(results: dict, bundle: dict, cfg: dict) -> pd.DataFrame:
    """Runs an independent 5-fold CV summary for sklearn-compatible models."""
    rs = cfg["project"]["random_state"]
    cv = StratifiedKFold(n_splits=cfg["tuning"]["cv_folds"], shuffle=True, random_state=rs)
    rows = []
    for name, info in results.items():
        if name.startswith("_") or name == "neural_network":
            continue
        model = info["model"]
        scores = cross_val_score(model, bundle["X_train"], bundle["y_train"],
                                  cv=cv, scoring="f1", n_jobs=-1)
        rows.append([name, scores.mean(), scores.std()])
        print(f"[evaluate_cv] {name}: f1 = {scores.mean():.4f} +/- {scores.std():.4f}")
    return pd.DataFrame(rows, columns=["model", "cv_f1_mean", "cv_f1_std"])


# ----------------------------------------------------------------------
# 5. Model Persistence
# ----------------------------------------------------------------------

def save_artifacts(results: dict, bundle: dict, cfg: dict):
    out_dir = cfg["artifacts"]["output_dir"]
    os.makedirs(out_dir, exist_ok=True)
    version_tag = datetime.now().strftime("%Y%m%d")

    # Pick "best" model by cv_f1 (fallback for NN uses val AUC already stored as cv_f1=None)
    scored = {k: v["cv_f1"] for k, v in results.items()
              if not k.startswith("_") and v.get("cv_f1") is not None}
    best_name = max(scored, key=scored.get) if scored else list(
        k for k in results if not k.startswith("_"))[0]
    best_model = results[best_name]["model"]

    prefix = cfg["artifacts"]["model_filename_prefix"]
    model_path = os.path.join(out_dir, f"{prefix}_v1.0_{version_tag}.pkl")
    best_model_path = os.path.join(out_dir, "best_model.pkl")

    if best_name == "neural_network":
        best_model.save(os.path.join(out_dir, "best_model.keras"))
        print(f"[save_artifacts] Saved Keras model to best_model.keras")
    else:
        joblib.dump(best_model, model_path)
        joblib.dump(best_model, best_model_path)
        print(f"[save_artifacts] Saved best model ({best_name}) to {best_model_path}")

    if cfg["artifacts"]["save_preprocessing"]:
        joblib.dump(bundle["scaler"], os.path.join(out_dir, "preprocessing_pipeline.pkl"))

    if cfg["artifacts"]["save_feature_list"]:
        with open(os.path.join(out_dir, "feature_list.txt"), "w") as f:
            f.write("\n".join(bundle["feature_list"]))

    # Save all trained models too (not just best) for comparison in evaluate_model.py
    for name, info in results.items():
        if name.startswith("_") or name == best_name:
            continue
        if name == "neural_network":
            info["model"].save(os.path.join(out_dir, f"{name}.keras"))
        else:
            joblib.dump(info["model"], os.path.join(out_dir, f"{name}.pkl"))

    results["_training_log"].to_csv(os.path.join(out_dir, "training_log.csv"), index=False)

    metadata = {
        "best_model": best_name,
        "version": version_tag,
        "random_state": cfg["project"]["random_state"],
        "class_names": bundle["class_names"],
        "imbalance_strategy": bundle["imbalance_strategy"],
        "n_features": len(bundle["feature_list"]),
    }
    with open(os.path.join(out_dir, "metadata.json"), "w") as f:
        json.dump(metadata, f, indent=2)

    print(f"[save_artifacts] Best model selected: {best_name}")
    print(f"[save_artifacts] All artifacts saved to: {out_dir}/")


# ----------------------------------------------------------------------
# Orchestration
# ----------------------------------------------------------------------

def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    np.random.seed(cfg["project"]["random_state"])

    print("=" * 60)
    print("THREAT DETECTION - TRAINING PIPELINE")
    print("=" * 60)

    df = load_data(cfg)
    bundle = preprocess(df, cfg)
    results = train_models(bundle, cfg)
    cv_summary = evaluate_cv(results, bundle, cfg)
    print("\n[main] Independent CV summary:\n", cv_summary)
    save_artifacts(results, bundle, cfg)

    # Persist test split for evaluate_model.py to reuse (avoids re-downloading data)
    out_dir = cfg["artifacts"]["output_dir"]
    np.savez_compressed(
        os.path.join(out_dir, "test_split.npz"),
        X_test=bundle["X_test"], y_test=bundle["y_test"]
    )

    print("\n[main] Training pipeline complete.")


if __name__ == "__main__":
    main()
