"""
evaluate_model.py
==================================================
Comprehensive model evaluation, threshold analysis,
SHAP interpretability, error analysis, and production
readiness check for the trained threat-detection model.

THE ARZENS Internship - Assignment 4, Task 3
==================================================

Usage:
    python evaluate_model.py --config config.yaml
"""

import os
import json
import time
import argparse
import warnings

import yaml
import joblib
import numpy as np
import pandas as pd
import matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
import seaborn as sns

from sklearn.metrics import (
    accuracy_score, precision_score, recall_score, f1_score,
    roc_auc_score, average_precision_score, roc_curve, precision_recall_curve,
    confusion_matrix, classification_report
)

warnings.filterwarnings("ignore")


# ----------------------------------------------------------------------
def load_config(path):
    with open(path, "r") as f:
        return yaml.safe_load(f)


def get_proba(model, X, is_keras=False):
    if is_keras:
        return model.predict(X, verbose=0).ravel()
    if hasattr(model, "predict_proba"):
        return model.predict_proba(X)[:, 1]
    return model.decision_function(X)


# ----------------------------------------------------------------------
# 1 & 2. Performance Metrics + Model Comparison
# ----------------------------------------------------------------------

def compute_metrics(y_true, y_prob, threshold=0.5):
    y_pred = (y_prob >= threshold).astype(int)
    tn, fp, fn, tp = confusion_matrix(y_true, y_pred).ravel()

    return {
        "accuracy": accuracy_score(y_true, y_pred),
        "precision": precision_score(y_true, y_pred, zero_division=0),
        "recall": recall_score(y_true, y_pred, zero_division=0),
        "f1": f1_score(y_true, y_pred, zero_division=0),
        "roc_auc": roc_auc_score(y_true, y_prob),
        "pr_auc": average_precision_score(y_true, y_prob),
        "fpr": fp / (fp + tn) if (fp + tn) else 0.0,
        "fnr": fn / (fn + tp) if (fn + tp) else 0.0,
        "tp": int(tp), "fp": int(fp), "tn": int(tn), "fn": int(fn),
    }


def compare_models(model_dir, X_test, y_test, cfg):
    """Loads every saved model in model_dir and scores it on the test set."""
    rows = []
    proba_cache = {}

    for fname in os.listdir(model_dir):
        name, ext = os.path.splitext(fname)
        if name in ("preprocessing_pipeline", "best_model") or ext not in (".pkl", ".keras"):
            continue

        path = os.path.join(model_dir, fname)
        is_keras = ext == ".keras"
        t0 = time.time()
        if is_keras:
            import tensorflow as tf
            model = tf.keras.models.load_model(path)
        else:
            model = joblib.load(path)

        y_prob = get_proba(model, X_test, is_keras=is_keras)
        infer_time_ms = (time.time() - t0) * 1000 / max(len(X_test), 1)

        m = compute_metrics(y_test, y_prob, threshold=0.5)
        m["model"] = name
        m["inference_ms_per_sample"] = infer_time_ms
        rows.append(m)
        proba_cache[name] = (model, y_prob, is_keras)

    df = pd.DataFrame(rows).set_index("model")
    return df, proba_cache


# ----------------------------------------------------------------------
# 3. Threshold Analysis
# ----------------------------------------------------------------------

def threshold_analysis(y_true, y_prob, thresholds, out_dir):
    rows = []
    for t in thresholds:
        m = compute_metrics(y_true, y_prob, threshold=t)
        m["threshold"] = t
        rows.append(m)
    df = pd.DataFrame(rows)

    precisions, recalls, pr_thresh = precision_recall_curve(y_true, y_prob)
    plt.figure(figsize=(7, 5))
    plt.plot(pr_thresh, precisions[:-1], label="Precision")
    plt.plot(pr_thresh, recalls[:-1], label="Recall")
    plt.xlabel("Threshold")
    plt.ylabel("Score")
    plt.title("Precision / Recall vs. Threshold")
    plt.legend()
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "threshold_curve.png"), dpi=120)
    plt.close()

    # Recommend threshold minimizing weighted cost: cost_fp*FP + cost_fn*FN
    cfg_dummy_costs = df.copy()
    return df


def recommend_threshold(df, cost_fp, cost_fn):
    df = df.copy()
    df["weighted_cost"] = cost_fp * df["fp"] + cost_fn * df["fn"]
    best_row = df.loc[df["weighted_cost"].idxmin()]
    return best_row


# ----------------------------------------------------------------------
# 4. SHAP Interpretability
# ----------------------------------------------------------------------

def shap_analysis(model, X_test, feature_names, out_dir, cfg, is_keras=False):
    import shap

    sample_n = min(cfg["interpretability"]["shap_sample_size"], len(X_test))
    idx = np.random.RandomState(cfg["project"]["random_state"]).choice(
        len(X_test), sample_n, replace=False
    )
    X_sample = X_test[idx]

    print("[shap_analysis] Computing SHAP values (this may take a while) ...")
    if is_keras:
        background = X_sample[:50]
        explainer = shap.KernelExplainer(lambda x: model.predict(x, verbose=0), background)
        shap_values = explainer.shap_values(X_sample[:100], nsamples=100)
        X_for_plot = X_sample[:100]
    else:
        explainer = shap.TreeExplainer(model)
        shap_values = explainer.shap_values(X_sample)
        if isinstance(shap_values, list):
            shap_values = shap_values[1]  # class "attack"
        X_for_plot = X_sample

    shap_dir = os.path.join(out_dir, "shap_analysis")
    os.makedirs(os.path.join(shap_dir, "dependence_plots"), exist_ok=True)
    os.makedirs(os.path.join(shap_dir, "force_plots_for_examples"), exist_ok=True)

    # Global: summary plot
    plt.figure()
    shap.summary_plot(shap_values, X_for_plot, feature_names=feature_names, show=False)
    plt.tight_layout()
    plt.savefig(os.path.join(shap_dir, "summary_plot.png"), dpi=120, bbox_inches="tight")
    plt.close()

    # Top N features by mean |SHAP|
    mean_abs = np.abs(shap_values).mean(axis=0)
    top_idx = np.argsort(mean_abs)[::-1][: cfg["interpretability"]["top_n_features"]]
    top_features = [(feature_names[i], float(mean_abs[i])) for i in top_idx]

    # Dependence plots for top 3 features
    for feat_name, _ in top_features[:3]:
        plt.figure()
        shap.dependence_plot(feat_name, shap_values, X_for_plot,
                              feature_names=feature_names, show=False)
        plt.tight_layout()
        safe_name = feat_name.replace("/", "_").replace(" ", "_")
        plt.savefig(os.path.join(shap_dir, "dependence_plots", f"{safe_name}.png"),
                    dpi=120, bbox_inches="tight")
        plt.close()

    return top_features, shap_values, X_for_plot


def explain_examples(y_true, y_prob, shap_values, X_for_plot, feature_names, out_dir, n_each=2):
    """Selects TP/FP/FN examples and writes plain-English explanations."""
    y_pred = (y_prob[: len(X_for_plot)] >= 0.5).astype(int)
    y_true_sub = np.array(y_true)[: len(X_for_plot)]

    tp_idx = np.where((y_true_sub == 1) & (y_pred == 1))[0][:n_each]
    fp_idx = np.where((y_true_sub == 0) & (y_pred == 1))[0][:n_each]
    fn_idx = np.where((y_true_sub == 1) & (y_pred == 0))[0][:1]

    explanations = []
    for label, idx_list in [("true_positive", tp_idx), ("false_positive", fp_idx),
                             ("false_negative", fn_idx)]:
        for i in idx_list:
            row_shap = shap_values[i]
            top3 = np.argsort(np.abs(row_shap))[::-1][:3]
            reasons = [f"{feature_names[j]} (SHAP={row_shap[j]:.3f})" for j in top3]
            explanations.append({
                "example_type": label,
                "index": int(i),
                "top_contributing_features": reasons,
                "plain_english": (
                    f"This sample was classified as it was, primarily driven by "
                    f"{reasons[0].split(' (')[0]}, {reasons[1].split(' (')[0]}, "
                    f"and {reasons[2].split(' (')[0]}."
                )
            })

    with open(os.path.join(out_dir, "shap_analysis", "example_explanations.json"), "w") as f:
        json.dump(explanations, f, indent=2)
    return explanations


# ----------------------------------------------------------------------
# 5. Error Analysis
# ----------------------------------------------------------------------

def error_analysis(y_true, y_prob, out_dir, threshold=0.5):
    y_pred = (y_prob >= threshold).astype(int)
    cm = confusion_matrix(y_true, y_pred)

    plt.figure(figsize=(5, 4))
    sns.heatmap(cm, annot=True, fmt="d", cmap="Blues",
                xticklabels=["Benign", "Attack"], yticklabels=["Benign", "Attack"])
    plt.xlabel("Predicted")
    plt.ylabel("Actual")
    plt.title("Confusion Matrix")
    plt.tight_layout()
    plt.savefig(os.path.join(out_dir, "confusion_matrix.png"), dpi=120)
    plt.close()

    report = classification_report(y_true, y_pred, target_names=["Benign", "Attack"],
                                    output_dict=True, zero_division=0)
    return cm, report


# ----------------------------------------------------------------------
# 6. Production Readiness
# ----------------------------------------------------------------------

def production_readiness(model, X_test, model_path, is_keras=False):
    n = min(1000, len(X_test))
    t0 = time.time()
    _ = get_proba(model, X_test[:n], is_keras=is_keras)
    latency_ms = (time.time() - t0) * 1000 / n

    if os.path.exists(model_path):
        size_mb = os.path.getsize(model_path) / (1024 * 1024)
    else:
        size_mb = None

    return {
        "latency_ms_per_sample": latency_ms,
        "latency_ok": latency_ms < 10,
        "model_size_mb": size_mb,
        "size_ok": (size_mb is not None and size_mb < 100),
    }


# ----------------------------------------------------------------------
# Report generation
# ----------------------------------------------------------------------

def write_model_card(cfg, best_name, comparison_df, threshold_row, out_dir):
    content = f"""# Model Card - Threat Detection Model

## Intended Use
Binary classification of network flow records as **Benign** or **Attack**,
trained on the CICIDS2017 dataset, intended to support (not replace) SOC
analyst triage.

## Model Details
- Best performing model: **{best_name}**
- Random state: {cfg['project']['random_state']}
- Imbalance handling: {cfg['preprocessing']['imbalance_strategy']}

## Performance (test set, threshold=0.5)
{comparison_df.round(4).to_markdown()}

## Recommended Operating Threshold
- Threshold: {threshold_row['threshold']:.2f}
- Precision: {threshold_row['precision']:.3f}
- Recall: {threshold_row['recall']:.3f}
- Rationale: chosen to minimize weighted cost where missed threats (false
  negatives) are penalized {cfg['evaluation']['cost_fn']}x more than false
  alarms (false positives), per `config.yaml`.

## Limitations
- Trained on CICIDS2017, a 2017-era synthetic testbed; real production
  traffic and newer attack families may differ (distribution drift).
- Binary framing collapses distinct attack types; per-attack-type recall
  should be monitored separately in a multi-class deployment.
- SHAP explanations are computed on a sampled subset for tractability.

## Ethical Considerations
- False negatives in security detection carry real-world risk; the model
  should be deployed as a decision-support alert generator, with human
  review, not a fully autonomous blocking system, until drift and
  adversarial-robustness testing is complete.
- Retrain on a regular cadence (recommended: monthly) with fresh attack
  samples to limit concept drift.
"""
    with open(os.path.join(out_dir, "model_card.md"), "w") as f:
        f.write(content)


# ----------------------------------------------------------------------
def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--config", default="config.yaml")
    args = parser.parse_args()

    cfg = load_config(args.config)
    out_dir = cfg["artifacts"]["output_dir"]

    print("=" * 60)
    print("THREAT DETECTION - EVALUATION PIPELINE")
    print("=" * 60)

    # Load test split saved by train_model.py
    npz = np.load(os.path.join(out_dir, "test_split.npz"))
    X_test, y_test = npz["X_test"], npz["y_test"]

    with open(os.path.join(out_dir, "feature_list.txt")) as f:
        feature_names = [l.strip() for l in f.readlines()]
    with open(os.path.join(out_dir, "metadata.json")) as f:
        metadata = json.load(f)

    # 1 & 2: metrics + comparison table
    comparison_df, proba_cache = compare_models(out_dir, X_test, y_test, cfg)
    print("\n[main] Model comparison (threshold=0.5):\n", comparison_df.round(4))
    comparison_df.to_csv(os.path.join(out_dir, "model_comparison.csv"))

    best_name = metadata["best_model"]
    if best_name not in proba_cache:
        best_name = comparison_df["f1"].idxmax()
    best_model, best_prob, best_is_keras = proba_cache[best_name]
    print(f"\n[main] Using '{best_name}' for threshold/SHAP/error analysis.")

    # 3: threshold analysis
    thr_df = threshold_analysis(y_test, best_prob, cfg["evaluation"]["thresholds_to_test"], out_dir)
    best_thr_row = recommend_threshold(thr_df, cfg["evaluation"]["cost_fp"], cfg["evaluation"]["cost_fn"])
    print("\n[main] Threshold analysis:\n", thr_df.round(4))
    print(f"\n[main] Recommended threshold: {best_thr_row['threshold']:.2f} "
          f"(precision={best_thr_row['precision']:.3f}, recall={best_thr_row['recall']:.3f})")

    # 4: SHAP
    try:
        top_features, shap_values, X_for_plot = shap_analysis(
            best_model, X_test, feature_names, out_dir, cfg, is_keras=best_is_keras
        )
        print("\n[main] Top features (SHAP):")
        for name, val in top_features:
            print(f"  {name}: {val:.4f}")
        explain_examples(y_test, best_prob, shap_values, X_for_plot, feature_names, out_dir)
    except Exception as e:
        print(f"[main] SHAP analysis skipped due to error: {e}")

    # 5: error analysis
    cm, report = error_analysis(y_test, best_prob, out_dir, threshold=best_thr_row["threshold"])
    print("\n[main] Confusion matrix:\n", cm)

    # 6: production readiness
    model_path = os.path.join(out_dir, "best_model.pkl" if not best_is_keras else "best_model.keras")
    readiness = production_readiness(best_model, X_test, model_path, is_keras=best_is_keras)
    print("\n[main] Production readiness:", readiness)

    # Report + model card
    write_model_card(cfg, best_name, comparison_df, best_thr_row, out_dir)

    full_report = {
        "best_model": best_name,
        "comparison": comparison_df.round(4).to_dict(),
        "recommended_threshold": best_thr_row.to_dict(),
        "confusion_matrix": cm.tolist(),
        "classification_report": report,
        "production_readiness": readiness,
    }
    with open(os.path.join(out_dir, "evaluation_report.json"), "w") as f:
        json.dump(full_report, f, indent=2, default=str)

    print("\n[main] Evaluation complete. Artifacts written to:", out_dir)


if __name__ == "__main__":
    main()
