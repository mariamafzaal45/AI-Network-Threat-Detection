# ML Threat Detection Pipeline — Assignment 4 (Task 2 + Task 3)

## Setup
```bash
pip install -r requirements_ml.txt
```

## Run training (Task 2)
```bash
python train_model.py --config config.yaml
```
This will:
- Download CICIDS2017 via `kagglehub` (`ericanacletoribeiro/cicids2017-cleaned-and-preprocessed`)
- Auto-detect the CSV, validate schema/quality, clean nulls/inf/duplicates
- Engineer features (drop near-duplicate correlated columns, scale, handle class imbalance)
- Train Random Forest, XGBoost, and a Keras Neural Network with hyperparameter search + 5-fold CV
- Save everything to `model_artifacts/`: `best_model.pkl`, `preprocessing_pipeline.pkl`,
  `feature_list.txt`, `training_log.csv`, `metadata.json`, `test_split.npz`, plus each
  individual model for later comparison.

## Run evaluation (Task 3)
```bash
python evaluate_model.py --config config.yaml
```
This will:
- Load every saved model and score it on the held-out test set (metrics table)
- Run threshold analysis (0.3 / 0.35 / 0.5 / 0.7) and recommend an operating threshold
  by weighted cost (config: `cost_fp` vs `cost_fn`)
- Run SHAP global (summary/dependence plots) and local (per-example) interpretability
- Produce a confusion matrix + classification report (error analysis)
- Check inference latency and model size against production thresholds (<10ms, <100MB)
- Write `model_comparison.csv`, `evaluation_report.json`, and `model_card.md`

## Notebook
Open `ML_Threat_Detection.ipynb` for EDA (class distribution, correlation heatmap),
a call into the training pipeline, and feature-importance visualization.

## Notes for your submission
- All random seeds are fixed to 42 (`config.yaml -> project.random_state`) for reproducibility.
- The dataset checksum is printed by `train_model.py` at load time — include it in your
  design brief / notebook as the "versioned dataset" reference.
- Task 1 (the design-brief PDF/DOCX) is a separate written deliverable — say the word if
  you want a draft of that too, once you've picked a scenario (A/B/C).
- Remember the assignment's AI Assistance Note requirement: disclose that this pipeline
  was built with AI assistance and briefly describe how.
